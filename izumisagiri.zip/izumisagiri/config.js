/*
Thanks to Botcahx
Thanks to Betabotz
Thanks to DyLux-FG
For Helping Create This Program Code
*/

import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['6285174306183', 'Whyuu_19', true],
  ['6285880029379']
] // Nomor Owner

global.mods = ['6285174306183'] 
global.prems = ['6285174306183', '6285880029379']

// apikey
global.lann = 'hG4oTG26'
// apikeylu di ganti menggunakan apikey yang di dapatkan di website https://api.betabotz.org. contohnya global.lann = 'nans' (contoh). cara mendapatkan apikey. masuk website > scroll ke bawah dan cari harga yang kamu mau ada juga yang free dan tekan > otomatis akan di arahkan untuk registrasi, isi data diri email dll. > kalo sudah klik profil dan di situ akan muncul apikey mu. terima kasih.

global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api-fgmods.ddns.net': 'mhdAnan',
  'https://api.betabotz.org': 'hG4oTG26'
}

global.APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://fg-nrtm.ddns.net',
  fgmods: 'https://api-fgmods.ddns.net',
  lann: 'https://api.betabotz.org'
}

// Watermark
global.nama = 'Whyuu_19' // nama owner
global.nomor = '6285756402624' // nomor owner
global.nans = 'Izumi Sagiri' // nama bot 
global.thumb = 'https://i.ibb.co/Rzvx7Zd/20230906-202906-0000.png' // thumbnail bot ( foto menu )
global.dygp = 'https://chat.whatsapp.com' // link group yang ada di menu

// Sticker wm
global.packname = 'Bot WhatsApp' 
global.author = '@whyuu_19' 
global.fgig = 'https://www.instagram.com/muhwahyuasri_19' // bebas tapi jangan kosong 
global.fgsc = 'https://github.com/nanzone' // bebas tapi jangan kosong
global.fgyt = 'https://nansoffc.my.id/' // bebas tapi jangan kosong
global.fgpyp = 'https://nansoffc.my.id' // bebas tapi jangan kosong
global.fglog = 'https://i.ibb.co/3d8xcRq/20230906-204336.jpg'

// Other
global.dana = '6285756402624'
global.lastm = 'SIMPLE BOT WHATSAPP BY Whyuu_19'

global.wait = 'Tunggu sebentar....'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // Peringatan maksimum

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})